package com.review1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.review1.model.Pharmacymodel;
import com.review1.repository.Pharmacyrepo;

@Service
public class Pharmacyservice {
	@Autowired
	Pharmacyrepo pharmrepo;
	public List<Pharmacymodel>getAllPharmacy()
	{
		List<Pharmacymodel>pharmList=pharmrepo.findAll();
		return pharmList;
	}
	public Pharmacymodel savepharmacymodel(Pharmacymodel p)
	{
		Pharmacymodel obj=pharmrepo.save(p);
		return obj;
	}
	public Pharmacymodel updatePharmacymodel(Pharmacymodel p)
	{
		Pharmacymodel obj1=pharmrepo.save(p);
		return obj1;
	}
	public void deletePharmacymodel(int id)
	{
		pharmrepo.deleteById(id);
	}
	public Pharmacymodel getPharmacymodel(int id)
	{
		Pharmacymodel p=pharmrepo.findById(id).get();
		return p;
	}
}
