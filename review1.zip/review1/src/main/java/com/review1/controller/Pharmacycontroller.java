package com.review1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.review1.model.Pharmacymodel;
import com.review1.service.Pharmacyservice;

@RestController
public class Pharmacycontroller {
	@Autowired
	Pharmacyservice pharmservice;
	
	@GetMapping(value="/fetchPhaarmacymodel")
	public List<Pharmacymodel>getAllPharmacymodel() 
	{
		List<Pharmacymodel>
		pharmList=pharmservice.getAllPharmacy();
		return pharmList;
	}
		@PostMapping(value="/savePharmacymodel")
	public Pharmacymodel savePharmacymodel(@RequestBody Pharmacymodel p)
	{
		return pharmservice.savepharmacymodel(p);
	}
	@PutMapping(value="/updatePharmacymodel")
	public Pharmacymodel updatePharmacymodel(@RequestBody Pharmacymodel p)
	{
		return pharmservice.savepharmacymodel(p);
	}
	@DeleteMapping("/deletePharmacymodel/{id}")
	public void deletePharmacymodel(@PathVariable("id")int id)
	{
		pharmservice.deletePharmacymodel(id);
	}
	@GetMapping(value="/getPharmacymodel/{id}")
	public Pharmacymodel getPharmacymodel(@PathVariable("id")int id)
	{
		return pharmservice.getPharmacymodel(id);
	}
}
